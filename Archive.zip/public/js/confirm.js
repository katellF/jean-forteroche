var conf = new ConfirmClass();

  // $('#confirmPublish_').click(conf.confirmPublish());
