<?php $this->titre = 'Erreur'; ?>

<p class="margin-top50 margin-bottom25 margin-left15"><a class="btn btn-primary bg-6BC3D1" href="javascript: history.go(-1)" id="backLink2">Retour</a></p>

<div class="container margin-top50 text-center border_notif">

    <h1 class="margin-bottom25">Une erreur est survenue</h1>


    <p><?= $msgError ?></p>

</div>



