
<?php
$this->title = htmlspecialchars('Envoyer un message');
?>
<div class="position-relative" id="content">
    <div class="min_height">
        <p class="margin-top50 margin-bottom25 margin-left15"><a href="index.php?action=home" class="btn btn-primary bg-6BC3D1">Retour à la page d'accueil</a></p>

        <div class="container margin-top50 text-center border_notif">
            <h1 class="margin-bottom25">Message Envoyé</h1>
            <p>L'auteur a bien reçu votre message.</p>
            <p>Il vous répondra dans les plus brefs délais.</p>
        </div>
    </div>
</div>
