
<div class="container text-center logout">

    <p class="font_size_3">Vous êtes déconnectés</p>

    <a href="index.php?action=connection" class="btn btn-info btn-lg active button_logout margin-right15">Se connecter <span class="sr-only">(current)</span></a>
    <a href="index.php?action=home" class="btn btn-info btn-lg active button_logout margin-left15">retour au site</a>

</div>