<?php $this->titre = 'Erreur'; ?>

<div class="container margin-top50 text-center border_notif">

    <h1 class="margin-bottom25">Cette page est inactive</h1>

</div>