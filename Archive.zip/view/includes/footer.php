<footer id="footer">

    <nav class="navbar  navbar-expand-lg navbar-dark bg-dark nav_footer">
        <div class="container">
            <div class="navbar-collapse row justify-content-center" id="navbarTogglerDemo03">
                <ul class="navbar-nav flex_rowR">
                    <li class="nav-item active margin_rightR">
                        <a class="nav-link" href="index.php?action=connection">Admin <span
                                class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item active margin_rightR">
                        <a class="nav-link" href="#">Mentions Légales</a>
                    </li>
                    <li class="nav-item active margin_rightR">
                        <a class="nav-link" href="index.php?action=contact">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</footer>