<script src="public/js/jquery-3.2.1.slim.min.js"></script>
<script src="public/js/popper.min.js"></script>
<script src="public/js/bootstrap.min.js"></script>
<script src="public/js/class_confirm.js"></script>
<script src="public/js/confirm.js"></script>